﻿using LayerApplication.Queries;
using LayerDomain.Entities;
using LayerDomain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerApplication.QueryHandlers;

public interface IProductQueryHandler 
{
    Task<List<ProductModel>> GetProductList(ProductQuery data);
    Task<ProductModel> GetProduct(int id);
}

public class ProductQueryHandler : IProductQueryHandler
{
    private readonly IProductRepository _productRepository;
    public ProductQueryHandler(IProductRepository productRepository)
    {
        _productRepository = productRepository;
    }

    public async Task<List<ProductModel>> GetProductList(ProductQuery data)
    {
        List<ProductModel> productModels = new List<ProductModel>();

        try
        {
            productModels = await _productRepository.GetProductsPaginated(data.PageNumber, data.PageSize);
        }
        catch(Exception ex)
        {
            throw ex;
        }

        return productModels;
    }

    public async Task<ProductModel> GetProduct(int id)
    {
        ProductModel productModels = new ProductModel();

        try
        {
            productModels = await _productRepository.GetProductById(id);
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return productModels;
    }
}
