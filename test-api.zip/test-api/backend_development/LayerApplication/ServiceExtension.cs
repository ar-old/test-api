﻿using LayerApplication.CommandHandlers;
using LayerApplication.QueryHandlers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace LayerApplication;

public static class ServiceExtension
{
    public static void AddApplicationService(this IServiceCollection serviceCollection, IConfiguration configuration)
    {
        serviceCollection.AddScoped<IRegisterCommandHandler, RegisterCommandHandler>();
        serviceCollection.AddScoped<ILoginCommandHandler, LoginCommandHandler>();
        serviceCollection.AddScoped<IProductCommandHandler, ProductCommandHandler>();
        serviceCollection.AddScoped<IProductQueryHandler, ProductQueryHandler>();
    }
}
