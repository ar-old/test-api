﻿using LayerApplication.Commands;
using LayerApplication.Logic;
using LayerDomain.Entities;
using LayerDomain.Interfaces;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace LayerApplication.CommandHandlers;

public interface IRegisterCommandHandler
{
    Task<bool> AddAccount(RegisterCommand data);
}
public class RegisterCommandHandler : IRegisterCommandHandler
{
    private readonly IUserRepository _userRepository;
    public RegisterCommandHandler(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public async Task<bool>AddAccount(RegisterCommand data)
    {
        var result = false;
        try
        {
            if (await _userRepository.IsEmailExists(data.Email))
            {
                throw new Exception("Email is exist");
            }

            if (await _userRepository.IsUsernameExists(data.Email))
            {
                throw new Exception("Username is exist");
            }

            CommonLogic commonLogic = new CommonLogic();
            UserModel userModel = new UserModel();
            userModel.Email = data.Email;
            userModel.Password = commonLogic.CreateMD5(data.Password);
            userModel.PhoneNumber = data.PhoneNumber;
            userModel.FullName = data.FullName;
            userModel.Username = data.Username;

            result = await _userRepository.InsertUser(userModel);
        }
        catch(Exception ex)
        {
            Log.Error($"{nameof(AddAccount)} - {ex.Message.ToString()}");
            throw new Exception($"{ex.Message}"); 
        }
        return result;
    }
}
