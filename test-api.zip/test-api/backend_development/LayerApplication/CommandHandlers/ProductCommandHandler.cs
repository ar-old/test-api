﻿using LayerApplication.Commands;
using LayerDomain.Entities;
using LayerDomain.Interfaces;
using LayerInfrastructure.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerApplication.CommandHandlers;

public interface IProductCommandHandler
{
    Task<bool> AddProduct(ProductCommand productCommand);
    Task<bool> UpdateProduct(ProductCommand productCommand);
    Task<bool> DeleteProduct(int id);
}

public class ProductCommandHandler : IProductCommandHandler
{
    private readonly IProductRepository _productRepository;
    public ProductCommandHandler(IProductRepository productRepository)
    {
        _productRepository = productRepository;
    }

    public async Task<bool> AddProduct(ProductCommand productCommand)
    {
        bool result = false;
        try
        {

            var validateProduct = await _productRepository.GetProductByName(productCommand.Name);
            if(validateProduct != null)
            {
                throw new Exception("Product name is already exist");
            }

            var product = new ProductModel
            { 
               Name = productCommand.Name,
               Description = productCommand.Description,
               Price = productCommand.Price,
               Stock = productCommand.Stock,
            };

            result = await _productRepository.InsertProduct(product);
            if(!result)
            {
                throw new Exception("Failed to insert new product");
            }
        }
        catch (Exception ex) 
        { 
            throw ex;
        }
        return result;
    }

    public async Task<bool> UpdateProduct(ProductCommand productCommand)
    {
        bool result = false;
        try
        {

            var validateProduct = await _productRepository.GetProductById(productCommand.Id);
            if (validateProduct == null)
            {
                throw new Exception("Product not exist");
            }

            if(validateProduct.Name == productCommand.Name)
            {
                throw new Exception("Product name is already exist");
            }

            var product = new ProductModel
            {
                Id = productCommand.Id,
                Name = productCommand.Name,
                Description = productCommand.Description,
                Price = productCommand.Price,
                Stock = productCommand.Stock,
            };

            result = await _productRepository.UpdateProductById(product);
            if (!result)
            {
                throw new Exception("Failed to update new product");
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return result;
    }

    public async Task<bool> DeleteProduct(int id)
    {
        bool result = false;
        try
        {
            var validateProduct = await _productRepository.GetProductById(id);
            if (validateProduct == null)
            {
                throw new Exception("Product not exist");
            }

            result = await _productRepository.DeleteProductById(id);
            if (!result)
            {
                throw new Exception("Failed to delete new product");
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return result;
    }

}
