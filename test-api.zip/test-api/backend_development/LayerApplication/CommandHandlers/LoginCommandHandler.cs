﻿using LayerApplication.Commands;
using LayerApplication.Logic;
using LayerDomain.Entities;
using LayerDomain.Interfaces;
using LayerInfrastructure.Utility;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace LayerApplication.CommandHandlers;

public interface ILoginCommandHandler
{
    Task<string> UserLogin(LoginCommand data);
}

public class LoginCommandHandler : ILoginCommandHandler
{
    private IAppConfigurationProvider _appConfigurationProvider = null;
    private readonly IUserRepository _userRepository;
    private readonly ITokenRepository _tokenRepository;
    public LoginCommandHandler(IAppConfigurationProvider appConfigurationProvider, IUserRepository userRepository, ITokenRepository tokenRepository)
    {
        _appConfigurationProvider = appConfigurationProvider;
        _userRepository = userRepository;
        _tokenRepository = tokenRepository;
    }

    public async Task<string> UserLogin(LoginCommand data)
    {
        var result = string.Empty;
        bool tokenExist = false;
        try
        {
            CommonLogic commonLogic = new CommonLogic();
            var password = commonLogic.CreateMD5(data.Password);

            var userData = await _userRepository.IsUserExists(data.Username, password);
            if (userData == null)
            {
                throw new Exception("User not exist");
            }

            var oldToken = await _tokenRepository.IsUserExistsToken(data.Username);
            if (oldToken != null)
            {
                tokenExist = true;
            }

            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Name, userData.FullName));
            claims.Add(new Claim("Email", userData.Email));
            claims.Add(new Claim("Username", userData.Username));

            var keys = _appConfigurationProvider.SecretKey;
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(keys));

            var signInCred = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);

            var token = new JwtSecurityToken
                (
                    issuer: keys,
                    expires: DateTime.Now.AddHours(8),
                    claims: claims.ToArray(),
                    signingCredentials: signInCred
                );

            var accessToken = new JwtSecurityTokenHandler().WriteToken(token);

            UserTokenModel userTokenModel = new UserTokenModel();
            userTokenModel.AccessToken = accessToken;
            userTokenModel.Email = userData.Email;
            userTokenModel.Username = userData.Username;
            userTokenModel.CreateDate = DateTime.Now;

            var insertToken = await _tokenRepository.InsertUserToken(userTokenModel, tokenExist, oldToken);
            if(insertToken)
            {
                result = accessToken;
            }
        }
        catch(Exception ex)
        {
            throw new Exception($"{ex.Message}");
        }
        return result;
    }
}
