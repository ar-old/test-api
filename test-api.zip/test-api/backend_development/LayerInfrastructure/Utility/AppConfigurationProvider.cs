﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerInfrastructure.Utility;

public interface IAppConfigurationProvider
{
    string Db { get; }
    string SecretKey { get; }
    string SqliteDb { get; }
}

public class AppConfigurationProvider : IAppConfigurationProvider
{
    private string _db = string.Empty;
    private string _secretKey = string.Empty;
    private string _sqliteDb = string.Empty;

    public AppConfigurationProvider(string Db, string secretKey, string sqliteDb)
    {
        _db = Db;
        _secretKey = secretKey;
        _sqliteDb = sqliteDb;
    }
    public string Db
    {
        get
        {
            return _db;
        }
    }
    public string SecretKey
    {
        get
        {
            return _secretKey;
        }
    }

    public string SqliteDb
    {
        get
        {
            return _sqliteDb;
        }
    }
}
