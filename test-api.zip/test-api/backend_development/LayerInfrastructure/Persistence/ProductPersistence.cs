﻿using Dapper;
using LayerDomain.Entities;
using LayerDomain.Interfaces;
using LayerInfrastructure.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerInfrastructure.Persistence;

public class ProductPersistence : IProductRepository
{
    private IAppConfigurationProvider _appConfigurationProvider = null;
    private SQLiteConnection _sqlite = null;
    public ProductPersistence(IAppConfigurationProvider appConfigurationProvider)
    {
        _appConfigurationProvider = appConfigurationProvider;
        _sqlite = new SQLiteConnection($"Data Source={_appConfigurationProvider.SqliteDb};Version=3;Synchronous=OFF;Journal Mode=WAL;");
    }

    public async Task<bool> InsertProduct(ProductModel data)
    {
        bool result = false;
        try
        {
            _sqlite.Open();
            string query = "INSERT INTO products (name, description, price, stock) " +
                           "VALUES (@Name, @Description, @Price, @Stock);";
            var dataResult = await _sqlite.ExecuteAsync(query, new
            {
                Name = data.Name,
                Description = data.Description,
                Price = data.Price,
                Stock = data.Stock
            });

            result = dataResult > 0;
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return result;
    }

    public async Task<bool> UpdateProductById(ProductModel data)
    {
        bool result = false;
        try
        {
            _sqlite.Open();
            string query = "UPDATE products SET name = @Name, description = @Description, price = @Price, stock = @Stock " +
                           "WHERE id = @Id;";
            var dataResult = await _sqlite.ExecuteAsync(query, new
            {
                Id = data.Id,
                Name = data.Name,
                Description = data.Description,
                Price = data.Price,
                Stock = data.Stock
            });

            result = dataResult > 0; // Returns true if at least one row was affected
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return result;
    }

    public async Task<bool> DeleteProductById(int id)
    {
        bool result = false;
        try
        {
            _sqlite.Open();
            string query = "DELETE FROM products WHERE id = @Id;";
            var dataResult = await _sqlite.ExecuteAsync(query, new { Id = id });
            result = dataResult > 0;
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return result;
    }

    public async Task<List<ProductModel>> GetProductsPaginated(int pageNumber, int pageSize)
    {
        List<ProductModel> products = new List<ProductModel>();
        try
        {
            _sqlite.Open();
            string query = @"SELECT id, name, description, price, stock, created_at 
                         FROM products 
                         ORDER BY created_at DESC 
                         LIMIT @PageSize OFFSET @Offset;";

            DefaultTypeMap.MatchNamesWithUnderscores = true;

            var data = await _sqlite.QueryAsync<ProductModel>(query, new
            {
                PageSize = pageSize,
                Offset = (pageNumber - 1) * pageSize
            });

            products = data.ToList();
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return products;
    }


    public async Task<ProductModel> GetProductByName(string productName)
    {
        ProductModel result = null;
        try
        {
            _sqlite.Open();
            string query = "SELECT id, name, description, price, stock, created_at FROM products WHERE name = @name;";
            DefaultTypeMap.MatchNamesWithUnderscores = true;
            var data = await _sqlite.QueryFirstOrDefaultAsync<ProductModel>(query, new { name = productName });
            result = data;
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return result;
    }

    public async Task<ProductModel> GetProductById(int id)
    {
        ProductModel result = null;
        try
        {
            _sqlite.Open();
            string query = "SELECT id, name, description, price, stock, created_at FROM products WHERE id = @id;";
            DefaultTypeMap.MatchNamesWithUnderscores = true;

            var data = await _sqlite.QueryFirstOrDefaultAsync<ProductModel>(query, new { id = id });

            result = data;
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return result;
    }


}
