﻿using Dapper;
using LayerDomain.Entities;
using LayerDomain.Interfaces;
using LayerInfrastructure.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerInfrastructure.Persistence;

public class UserPersistence : IUserRepository
{
    private IAppConfigurationProvider _appConfigurationProvider = null;
    private SQLiteConnection _sqlite = null;
    public UserPersistence(IAppConfigurationProvider appConfigurationProvider)
    {
        _appConfigurationProvider = appConfigurationProvider;
        _sqlite = new SQLiteConnection($"Data Source={_appConfigurationProvider.SqliteDb};Version=3;Synchronous=OFF;Journal Mode=WAL;");
    }

    public async Task<bool> IsEmailExists(string email)
    {
        bool exists = false;
        try
        {
            _sqlite.Open();
            string query = "SELECT COUNT(*) FROM users WHERE email = @email;";
            int count = await _sqlite.QueryFirstOrDefaultAsync<int>(query, new { email = email });
            exists = count > 0;
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return exists;
    }

    public async Task<bool> IsUsernameExists(string username)
    {
        bool exists = false;
        try
        {
            _sqlite.Open();
            string query = "SELECT COUNT(*) FROM users WHERE username = @username;";
            int count = await _sqlite.QueryFirstOrDefaultAsync<int>(query, new { username = username });
            exists = count > 0;
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return exists;
    }

    public async Task<UserModel> IsUserExists(string username, string password)
    {
        UserModel result = null;
        try
        {
            _sqlite.Open();
            string query = "SELECT username, email, full_name FROM users WHERE (username = @username OR email = @username) AND password = @password;";
            DefaultTypeMap.MatchNamesWithUnderscores = true;
            var data = await _sqlite.QueryFirstOrDefaultAsync<UserModel>(query, new { username = username, password = password });
            result = data;
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return result;
    }


    public async Task<bool> InsertUser(UserModel user)
    {
        bool result = false;
        try
        {
            _sqlite.Open();


            string query = "INSERT INTO users (username, password, email, full_name, phone_number) " +
                           "VALUES (@Username, @Password, @Email, @FullName, @PhoneNumber);";

            var dataResult = await _sqlite.ExecuteAsync(query, new
            {
                Username = user.Username,
                Password = user.Password,
                Email = user.Email,
                FullName = user.FullName,
                PhoneNumber = user.PhoneNumber
            });

            if (dataResult > 0)
                result = true;
            else
                Log.Error("Failed to insert user in InsertUser.");
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return result;
    }

}
