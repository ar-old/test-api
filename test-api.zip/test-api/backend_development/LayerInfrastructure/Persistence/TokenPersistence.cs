﻿using Dapper;
using LayerDomain.Entities;
using LayerDomain.Interfaces;
using LayerInfrastructure.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerInfrastructure.Persistence;

public class TokenPersistence : ITokenRepository
{
    private IAppConfigurationProvider _appConfigurationProvider = null;
    private SQLiteConnection _sqlite = null;
    public TokenPersistence(IAppConfigurationProvider appConfigurationProvider)
    {
        _appConfigurationProvider = appConfigurationProvider;
        _sqlite = new SQLiteConnection($"Data Source={_appConfigurationProvider.SqliteDb};Version=3;Synchronous=OFF;Journal Mode=WAL;");
    }

    public async Task<bool> InsertUserToken(UserTokenModel tokenModel, bool isExistOldToken, string oldAccessToken)
    {
        bool result = false;
        _sqlite.Open();
        using (var transaction = _sqlite.BeginTransaction())
        {
            try
            {
                string query = "INSERT INTO user_tokens (access_token, email, username, create_date) " +
                          "VALUES (@AccessToken, @Email, @Username, @CreateDate);";

                var dataResult = await _sqlite.ExecuteAsync(query, new
                {
                    AccessToken = tokenModel.AccessToken,
                    Email = tokenModel.Email,
                    Username = tokenModel.Username,
                    CreateDate = tokenModel.CreateDate
                });

                if (dataResult == 0)
                {
                    Log.Error($"Failed to insert {nameof(InsertUserToken)}");
                    transaction.Rollback();
                    throw new Exception("Failed to process token");
                }

                if(isExistOldToken)
                {
                    string deleteQuery = "DELETE FROM user_tokens WHERE access_token = @access_token;";
                    int deleteResult = await _sqlite.ExecuteAsync(deleteQuery, new { access_token = oldAccessToken });

                    if (deleteResult == 0)
                    {
                        transaction.Rollback();
                        throw new Exception("Failed to process token");
                    }
                }

                transaction.Commit(); 
                result = true;
            }
            catch (Exception ex)
            {
                Log.Error(ex.ToString());
                transaction.Rollback();
                return result;
            }
            finally
            {
                _sqlite?.Close();
            }
        }
        return result;
    }

    public async Task<string> IsUserExistsToken(string username)
    {
        var result = string.Empty;
        try
        {
            _sqlite.Open();
            string query = "SELECT access_token FROM user_tokens WHERE (username = @username OR email = @username);";
            DefaultTypeMap.MatchNamesWithUnderscores = true;
            var data = await _sqlite.QueryFirstOrDefaultAsync<string>(query, new { username = username });
            result = data;
        }
        catch (Exception ex)
        {
            Log.Error(ex.ToString());
        }
        finally
        {
            _sqlite?.Close();
        }
        return result;
    }
}
