﻿using LayerDomain.Interfaces;
using LayerInfrastructure.Persistence;
using LayerInfrastructure.Utility;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace LayerInfrastructure;

public static class ServiceExtension
{
    private static IServiceProvider _serviceProvider;

    public static void AddInfrastructureService(this IServiceCollection serviceCollection, IConfiguration configuration)
    {
        serviceCollection.AddScoped<IUserRepository, UserPersistence>();
        serviceCollection.AddScoped<ITokenRepository, TokenPersistence>();
        serviceCollection.AddScoped<IProductRepository, ProductPersistence>();
        serviceCollection.AddSingleton<IAppConfigurationProvider>(
            new AppConfigurationProvider(
                configuration["ConnectionStrings:Db"],
                configuration["SecretKey"],
                configuration["SqliteDb"])
            );
    }

    public static void SetLocationProvider(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public static T? GetService<T>()
    {
        return _serviceProvider.GetService<T>();
    }
}
