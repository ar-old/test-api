﻿using LayerDomain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerDomain.Interfaces;

public interface IProductRepository
{
    Task<bool> InsertProduct(ProductModel data);
    Task<bool> UpdateProductById(ProductModel data);
    Task<bool> DeleteProductById(int id);
    Task<List<ProductModel>> GetProductsPaginated(int pageNumber, int pageSize);
    Task<ProductModel> GetProductByName(string productName);
    Task<ProductModel> GetProductById(int id);
}
