﻿using LayerDomain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerDomain.Interfaces;

public interface ITokenRepository
{
    Task<bool> InsertUserToken(UserTokenModel tokenModel, bool isExistOldToken, string oldAccessToken);
    Task<string> IsUserExistsToken(string username);
}
