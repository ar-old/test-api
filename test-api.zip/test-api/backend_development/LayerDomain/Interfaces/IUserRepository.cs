﻿using LayerDomain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerDomain.Interfaces;

public interface IUserRepository
{
    Task<bool> IsEmailExists(string email);
    Task<bool> IsUsernameExists(string username);
    Task<UserModel> IsUserExists(string username, string password);
    Task<bool> InsertUser(UserModel user);
}
