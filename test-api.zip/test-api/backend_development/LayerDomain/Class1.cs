﻿namespace LayerDomain;

public class Class1
{

}
