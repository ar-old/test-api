﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayerDomain.Entities;

public class UserTokenModel
{
    public string AccessToken { get; set; }
    public string Email { get; set; }
    public string Username { get; set; }
    public DateTime CreateDate { get; set; }
}