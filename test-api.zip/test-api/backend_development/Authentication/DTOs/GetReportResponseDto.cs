﻿using System.Text.Json.Serialization;

namespace Authentication.DTOs;

public class GetReportResponseDto
{
    [JsonPropertyName("status")] public int Status { get; set; }
    [JsonPropertyName("message")] public string Message { get; set; } = "";
}
