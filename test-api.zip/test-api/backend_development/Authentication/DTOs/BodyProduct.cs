﻿using System.Text.Json.Serialization;

namespace Authentication.DTOs;

public class BodyProduct
{
    public string name { get; set; }
    public string description { get; set; } 
    public decimal price { get; set; } 
    public int stock { get; set; }
}
