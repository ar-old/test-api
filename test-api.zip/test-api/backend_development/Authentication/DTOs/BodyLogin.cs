﻿using System.ComponentModel.DataAnnotations;

namespace Authentication.DTOs;

public class BodyLogin
{
    [Required(ErrorMessage = "Username is required")]
    [StringLength(50, MinimumLength = 5, ErrorMessage = "Username must be between 5 and 50 characters")]
    public string username { get; set; }

    [Required(ErrorMessage = "Password is required")]
    [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters")]
    public string password { get; set; }
}
