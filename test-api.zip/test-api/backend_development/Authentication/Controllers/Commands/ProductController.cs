﻿using Authentication.DTOs;
using LayerApplication.CommandHandlers;
using LayerApplication.Commands;
using Microsoft.AspNetCore.Mvc;

namespace Authentication.Controllers.Commands;

public class ProductController : Controller
{
    private IProductCommandHandler _productCommandHandler;
    public ProductController(IProductCommandHandler productCommandHandler)
    {
        _productCommandHandler = productCommandHandler;
    }

    [HttpPost]
    [Route("products")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> AddProduct([FromBody] BodyProduct bodyDto)
    {
        try
        {
            var data = new ProductCommand
            {
                Name = bodyDto.name,
                Description = bodyDto.description,
                Price = bodyDto.price,
                Stock = bodyDto.stock,
            };

            var result = await _productCommandHandler.AddProduct(data);
            if (result)
                return Ok();
            else
                throw new Exception("Failed to insert new product");
        }
        catch (Exception ex)
        {
            return BadRequest(new GetReportResponseDto
            {
                Status = 400,
                Message = $"{ex.Message}"
            });
        }
    }

    [HttpPut]
    [Route("products/{id}")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UpdateProduct([FromRoute] int id, [FromBody] BodyProduct bodyDto)
    {
        try
        {
            var data = new ProductCommand
            {
                Id = id,
                Name = bodyDto.name,
                Description = bodyDto.description,
                Price = bodyDto.price,
                Stock = bodyDto.stock,
            };
            var result = await _productCommandHandler.UpdateProduct(data);
            if (result)
                return Ok();
            else
                throw new Exception("Failed to insert new product");
        }
        catch (Exception ex)
        {
            return BadRequest(new GetReportResponseDto
            {
                Status = 400,
                Message = $"{ex.Message}"
            });
        }
    }

    [HttpDelete]
    [Route("products/{id}")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> DeleteProduct([FromRoute] int id)
    {
        try
        {
            var result = await _productCommandHandler.DeleteProduct(id);
            if (result)
                return Ok();
            else
                throw new Exception("Failed to insert new product");
        }
        catch (Exception ex)
        {
            return BadRequest(new GetReportResponseDto
            {
                Status = 400,
                Message = $"{ex.Message}"
            });
        }
    }


}
