﻿using Authentication.DTOs;
using LayerApplication.CommandHandlers;
using LayerApplication.Commands;
using Microsoft.AspNetCore.Mvc;

namespace Authentication.Controllers.Commands;

public class UserController : Controller
{
    private IRegisterCommandHandler _registerCommandHandler;
    private ILoginCommandHandler _loginCommandHandler;

    public UserController(IRegisterCommandHandler registerCommandHandler, ILoginCommandHandler loginCommandHandler)
    {
        _registerCommandHandler = registerCommandHandler;
        _loginCommandHandler = loginCommandHandler;
    }

    [HttpPost]
    [Route("auth/register")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UserRegistration([FromBody] BodyRegistration bodyDto)
    {
        try
        {
            var data = new RegisterCommand
            {
                Username = bodyDto.username,
                Password = bodyDto.password,
                Email = bodyDto.email,
                FullName = bodyDto.full_name,
                PhoneNumber = bodyDto.phone_number,
            };

            if (await _registerCommandHandler.AddAccount(data))
                return Ok();

            else
                throw new Exception("Failed to register");
        }
        catch (Exception ex) 
        {
            return BadRequest(new GetReportResponseDto
            {
                Status = 400,
                Message = $"{ex.Message}"
            });
        }
    }

    [HttpPost]
    [Route("auth/login")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UserLogin([FromBody] BodyLogin bodyDto)
    {
        try
        {
            var data = new LoginCommand
            {
                Username = bodyDto.username,
                Password = bodyDto.password,
            };

            var token = await _loginCommandHandler.UserLogin(data);
            if(token != "" || token != null)
                return Ok(token);
            else
                throw new Exception("Failed to login");
        }
        catch (Exception ex)
        {
            return BadRequest(new GetReportResponseDto
            {
                Status = 400,
                Message = $"{ex.Message}"
            });
        }
    }

}
