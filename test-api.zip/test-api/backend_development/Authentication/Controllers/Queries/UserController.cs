﻿using Authentication.DTOs;
using LayerApplication.CommandHandlers;
using LayerApplication.Commands;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace Authentication.Controllers.Queries;

public class UserController : Controller
{
    private IRegisterCommandHandler _registerCommandHandler;
    private ILoginCommandHandler _loginCommandHandler;

    public UserController(IRegisterCommandHandler registerCommandHandler, ILoginCommandHandler loginCommandHandler)
    {
        _registerCommandHandler = registerCommandHandler;
        _loginCommandHandler = loginCommandHandler;
    }

    [HttpGet]
    [Route("user/me")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UserRegistration()
    {
        try
        {
            var authorizationHeader = Request.Headers["api-key"].ToString();

            if (string.IsNullOrEmpty(authorizationHeader) || !authorizationHeader.StartsWith("Bearer "))
            {
                return Unauthorized("Missing or invalid Authorization header.");
            }

            var token = authorizationHeader.Replace("Bearer ", "");

            var tokenHandler = new JwtSecurityTokenHandler();
            var jwtToken = tokenHandler.ReadJwtToken(token); // Decode the token

            if (jwtToken == null)
            {
                return Unauthorized("Invalid token.");
            }

            // Extract claims
            var username = jwtToken.Claims.FirstOrDefault(c => c.Type == "Username")?.Value;
            var email = jwtToken.Claims.FirstOrDefault(c => c.Type == "Email")?.Value;
            var fullName = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email))
            {
                return Unauthorized("Invalid token claims.");
            }

            return Ok(new
            {
                Username = username,
                Email = email,
                FullName = fullName
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new GetReportResponseDto
            {
                Status = 400,
                Message = $"{ex.Message}"
            });
        }
    }
}
