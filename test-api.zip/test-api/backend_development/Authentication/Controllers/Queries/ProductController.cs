﻿using Authentication.DTOs;
using LayerApplication.Queries;
using LayerApplication.QueryHandlers;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace Authentication.Controllers.Queries;

public class ProductController : Controller
{
    private IProductQueryHandler _productQueryHandler;
    public ProductController(IProductQueryHandler productQueryHandler)
    {
        _productQueryHandler = productQueryHandler;
    }


    [HttpGet]
    [Route("products")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetProductList([FromQuery] int page_number, [FromQuery] int page_size)
    {
        try
        {
            var data = new ProductQuery
            {
                PageNumber = page_number,
                PageSize = page_size
            };
            var result = await _productQueryHandler.GetProductList(data);
            if (result.Count() > 0)
                return Ok(result);
            else
                throw new Exception("No Available data");
        }
        catch (Exception ex)
        {
            return BadRequest(new GetReportResponseDto
            {
                Status = 400,
                Message = $"{ex.Message}"
            });
        }
    }

    [HttpGet]
    [Route("products/{id}")]
    [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(GetReportResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(string), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetProduct([FromRoute] int id)
    {
        try
        {
            var result = await _productQueryHandler.GetProduct(id);
            return Ok(result);
        }
        catch (Exception ex)
        {
            return BadRequest(new GetReportResponseDto
            {
                Status = 400,
                Message = $"{ex.Message}"
            });
        }
    }
}
